/**
 * Created by gustem on 20/04/2017.
 */
public class steve extends GameEngine {

    public static void main(String args[]) {


    }

    @Override
    public void update(double dt) {

    }

    @Override
    public void paintComponent() {

    }
}
